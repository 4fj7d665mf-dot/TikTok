# TikTok Username iOS Mod Menu — GitHub Actions build

This repository is an overlay for:

- https://github.com/xelahot/iOS-Mod-Menu-Base

The GitHub Actions workflow clones the upstream mod-menu base, applies the files in `overlay/`, builds it with Theos, and uploads the resulting dylib as a GitHub Actions artifact.

## Menu flow

1. Open the injected menu.
2. Enter `Session ID`.
3. Press Return or leave the field.
4. The current TikTok username is fetched automatically.
5. Enter `New Username`.
6. Tap `Enter`.
7. The username-change API is called.
8. The profile is fetched again and compared with the requested username.
9. A success/failure popup is shown.
10. The menu panel closes.

## Build on GitHub

1. Create a new GitHub repository.
2. Upload **all files and folders from this ZIP**, including `.github`.
3. Commit/push them to `main` or `master`.
4. Open the repository's **Actions** tab.
5. Select **Build iOS dylib**.
6. Choose **Run workflow**. A push to `main`/`master` also starts a build automatically.
7. When the job completes, download the artifact named `TikTokUsernameMenu-iOS-dylib`.

The artifact contains:

- `TikTokUsernameMenu.dylib`
- `TikTokUsernameMenu.plist`
- `NativeSNS.mm`
- `SHA256SUMS.txt`

## Target process

`overlay/xelahotmodmenubase.plist` filters injection to:

`com.zhiliaoapp.musically`

## Source layout

- `overlay/Tweak.xm` — menu and requested UI flow
- `overlay/SNSMenuHook.xm` — detects Session ID field completion
- `overlay/NativeSNS.mm` — native API/signature/profile/change implementation
- `overlay/NativeSNS.h` — exported native interface
- `overlay/SNSFlow.h` — menu callback declaration
- `overlay/Makefile` — Theos source list/framework configuration
- `overlay/xelahotmodmenubase.plist` — target bundle filter
- `build_project.sh` — clones upstream and applies the overlay
- `.github/workflows/build.yml` — GitHub Actions build

## Important

`sessionid` is an authentication credential. Use only a session belonging to an account you are authorized to control, do not hard-code it into source, and do not commit a real session ID to GitHub.

The HTTP endpoints/signature logic are based on the supplied Python implementation. A successful compile does not guarantee that TikTok currently accepts the private API request; server-side behavior can change.
