#!/usr/bin/env bash
set -euo pipefail

UPSTREAM="https://github.com/xelahot/iOS-Mod-Menu-Base.git"
BUILD_DIR="${GITHUB_WORKSPACE:-$(pwd)}/_upstream_build"
OUTPUT_DIR="${GITHUB_WORKSPACE:-$(pwd)}/output"
OVERLAY_DIR="${GITHUB_WORKSPACE:-$(pwd)}/overlay"

rm -rf "$BUILD_DIR" "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

git clone --depth 1 "$UPSTREAM" "$BUILD_DIR"

for file in \
  Makefile \
  Tweak.xm \
  NativeSNS.h \
  NativeSNS.mm \
  SNSFlow.h \
  SNSMenuHook.xm \
  xelahotmodmenubase.plist; do
  cp -f "$OVERLAY_DIR/$file" "$BUILD_DIR/$file"
done

cd "$BUILD_DIR"
make clean
make FINALPACKAGE=1

DYLIB_PATH="$(find .theos -type f -name 'xelahotmodmenubase.dylib' -print -quit)"
if [[ -z "$DYLIB_PATH" || ! -f "$DYLIB_PATH" ]]; then
  echo "ERROR: xelahotmodmenubase.dylib was not produced."
  find .theos -maxdepth 6 -type f -print || true
  exit 1
fi

cp -f "$DYLIB_PATH" "$OUTPUT_DIR/TikTokUsernameMenu.dylib"
cp -f xelahotmodmenubase.plist "$OUTPUT_DIR/TikTokUsernameMenu.plist"

# Include the exact source used for the network/API implementation in the artifact.
cp -f NativeSNS.mm "$OUTPUT_DIR/NativeSNS.mm"

shasum -a 256 "$OUTPUT_DIR"/* > "$OUTPUT_DIR/SHA256SUMS.txt"

echo "Build complete:"
ls -lah "$OUTPUT_DIR"
