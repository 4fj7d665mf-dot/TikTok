#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#if defined(__GNUC__)
#define SNS_EXPORT __attribute__((visibility("default")))
#else
#define SNS_EXPORT
#endif

// Returned strings are heap-allocated. Release them with sns_free().
SNS_EXPORT char *sns_run(const char *param, const char *stub, const char *cookie);
SNS_EXPORT char *sns_x_gorgon(const char *param, const void *data, unsigned long data_len, const char *cookie);
SNS_EXPORT char *sns_get_stub(const void *data, unsigned long data_len);
SNS_EXPORT char *sns_get_profile(const char *session_id, const char *device_id, const char *iid);
SNS_EXPORT int sns_check_is_changed(const char *last_username, const char *session_id, const char *device_id, const char *iid);
SNS_EXPORT char *sns_change_username(const char *session_id,
                                     const char *device_id,
                                     const char *iid,
                                     const char *last_username,
                                     const char *new_username);

// Equivalent to the original Python main flow, except values are passed as arguments.
SNS_EXPORT char *sns_change_username_auto(const char *session_id, const char *new_username);

SNS_EXPORT void sns_free(void *ptr);

#ifdef __cplusplus
}
#endif
