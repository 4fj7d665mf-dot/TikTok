#pragma once
#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif

// Called automatically when the Session ID text field is committed / loses focus.
void SNS_OnSessionEntered(NSString *sessionID);

#ifdef __cplusplus
}
#endif
