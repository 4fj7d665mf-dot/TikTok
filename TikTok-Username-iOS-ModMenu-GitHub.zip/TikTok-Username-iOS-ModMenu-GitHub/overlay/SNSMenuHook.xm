#import <UIKit/UIKit.h>
#import "Menu.h"
#import "SNSFlow.h"

static NSString *SNSItemTitleForTextField(Menu *menuRef, UITextField *textField) {
    if (!menuRef || !textField) return nil;

    NSInteger index = textField.tag;
    NSArray *items = menuRef.ScrollViewRef.subviews;
    if (index < 0 || index >= (NSInteger)items.count) return nil;

    UIView *itemView = items[(NSUInteger)index];
    for (UIView *subview in itemView.subviews) {
        if ([subview isKindOfClass:[UILabel class]]) {
            return ((UILabel *)subview).text;
        }
    }
    return nil;
}

%hook Menu

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSString *title = SNSItemTitleForTextField(self, textField);
    BOOL result = %orig;

    if ([title isEqualToString:@"Session ID"]) {
        SNS_OnSessionEntered(textField.text ?: @"");
    }
    return result;
}

// The original base does not implement this delegate method. Adding it means
// tapping away from the Session ID field also starts the automatic lookup.
%new
- (void)textFieldDidEndEditing:(UITextField *)textField {
    NSString *title = SNSItemTitleForTextField(self, textField);
    if ([title isEqualToString:@"Session ID"]) {
        SNS_OnSessionEntered(textField.text ?: @"");
    }
}

%end
