#import <UIKit/UIKit.h>

#import "Menu.h"
#import "Page.h"
#import "TextfieldItem.h"
#import "InvokeItem.h"
#import "Utils.h"
#import "NativeSNS.h"
#import "SNSFlow.h"

#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)((sec) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^

static Menu *menu = nil;
static NSString *gCurrentUsername = nil;
static NSString *gCurrentSessionID = nil;
static BOOL gBusy = NO;

static NSString *SNSStringFromOwnedCString(char *raw) {
    if (!raw) return @"";
    NSString *value = [NSString stringWithUTF8String:raw] ?: @"";
    sns_free(raw);
    return value;
}

static NSString *SNSTrim(NSString *value) {
    return [(value ?: @"") stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

static UITextField *SNSFindTextField(UIView *view) {
    if ([view isKindOfClass:[UITextField class]]) {
        return (UITextField *)view;
    }
    for (UIView *subview in view.subviews) {
        UITextField *found = SNSFindTextField(subview);
        if (found) return found;
    }
    return nil;
}

// Read the visible UITextField directly so tapping the Enter menu item also works
// even if the keyboard Return key was not pressed first.
static NSString *SNSLiveTextfieldValue(NSString *title) {
    if (!menu) return @"";

    UIScrollView *scrollView = menu.ScrollViewRef;
    for (UIView *itemView in scrollView.subviews) {
        NSString *itemTitle = nil;
        for (UIView *subview in itemView.subviews) {
            if ([subview isKindOfClass:[UILabel class]]) {
                itemTitle = ((UILabel *)subview).text;
                break;
            }
        }

        if ([itemTitle isEqualToString:title]) {
            UITextField *textField = SNSFindTextField(itemView);
            if (textField) return textField.text ?: @"";
        }
    }

    return [menu getTextfieldValue:title] ?: @"";
}

static void SNSShow(NSString *title, NSString *message) {
    dispatch_async(dispatch_get_main_queue(), ^{
        showPopup(title ?: @"TikTok", message ?: @"");
    });
}

extern "C" void SNS_OnSessionEntered(NSString *sessionID) {
    NSString *session = SNSTrim(sessionID);
    if (session.length == 0) return;

    // Avoid duplicate calls caused by Return -> resignFirstResponder -> didEndEditing.
    if (gBusy) return;
    if (gCurrentUsername && [gCurrentSessionID isEqualToString:session]) return;

    gBusy = YES;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *username = SNSStringFromOwnedCString(
            sns_get_profile(session.UTF8String, "", "")
        );

        dispatch_async(dispatch_get_main_queue(), ^{
            gBusy = NO;

            if (username.length == 0 || [username isEqualToString:@"None"]) {
                gCurrentUsername = nil;
                gCurrentSessionID = nil;
                showPopup(@"TikTok", @"現在のUsernameを取得できませんでした。Session IDを確認してください。");
                return;
            }

            gCurrentUsername = username;
            gCurrentSessionID = session;
            showPopup(@"現在のUsername", username);
        });
    });
}

static void SNSExecuteUsernameChange(void) {
    if (gBusy) {
        SNSShow(@"TikTok", @"現在処理中です。");
        return;
    }

    NSString *session = SNSTrim(SNSLiveTextfieldValue(@"Session ID"));
    NSString *newUsername = SNSTrim(SNSLiveTextfieldValue(@"New Username"));

    if (session.length == 0) {
        SNSShow(@"TikTok", @"Session IDを入力してください。");
        return;
    }
    if (newUsername.length == 0) {
        SNSShow(@"TikTok", @"新しいUsernameを入力してください。");
        return;
    }

    gBusy = YES;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // If the user tapped Enter before the automatic profile lookup completed,
        // obtain the current username here so the requested flow still completes.
        NSString *before = nil;
        if (gCurrentUsername && [gCurrentSessionID isEqualToString:session]) {
            before = gCurrentUsername;
        } else {
            before = SNSStringFromOwnedCString(
                sns_get_profile(session.UTF8String, "", "")
            );
        }

        if (before.length == 0 || [before isEqualToString:@"None"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                gBusy = NO;
                showPopup(@"TikTok", @"現在のUsernameを取得できませんでした。Session IDを確認してください。");
            });
            return;
        }

        // NativeSNS keeps the original Python flow: random device_id/iid,
        // change API, then profile re-check.
        NSString *apiResult = SNSStringFromOwnedCString(
            sns_change_username_auto(session.UTF8String, newUsername.UTF8String)
        );

        // Final exact verification: re-read the profile and compare it with the
        // requested username.
        NSString *after = SNSStringFromOwnedCString(
            sns_get_profile(session.UTF8String, "", "")
        );

        BOOL changedExactly = [after isEqualToString:newUsername];
        NSString *message = nil;

        if (changedExactly) {
            message = [NSString stringWithFormat:
                @"変更成功\n\n変更前: %@\n変更後: %@",
                before, after];
        } else {
            message = [NSString stringWithFormat:
                @"変更を確認できませんでした。\n\nAPI: %@\n現在: %@",
                apiResult.length ? apiResult : @"(no response)",
                after.length ? after : @"取得失敗"];
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            gBusy = NO;
            gCurrentUsername = (after.length && ![after isEqualToString:@"None"]) ? after : before;
            gCurrentSessionID = session;

            showPopup(changedExactly ? @"TikTok - Success" : @"TikTok - Result", message);

            // "Enterで終了": close only the panel. The floating menu button remains
            // because the original base adds it directly to the app window.
            menu.alpha = 0.0f;
        });
    });
}

static void initMenu(void) {
    menu = [[Menu alloc] initMenu];

    TextfieldItem *sessionItem = [[TextfieldItem alloc] init];
    sessionItem.Title = @"Session ID";
    sessionItem.Description = @"TikTok sessionid を入力。入力確定後、現在のUsernameを自動取得します。";
    sessionItem.IsOn = NO;
    sessionItem.DefaultValue = @"";

    TextfieldItem *usernameItem = [[TextfieldItem alloc] init];
    usernameItem.Title = @"New Username";
    usernameItem.Description = @"変更したい新しいUsernameを入力します。";
    usernameItem.IsOn = NO;
    usernameItem.DefaultValue = @"";

    InvokeItem *enterItem = [[InvokeItem alloc] init];
    enterItem.Title = @"Enter";
    enterItem.Description = @"Username変更APIを実行し、変更後のUsernameを自動確認してメニューを閉じます。";
    enterItem.FunctionPtr = &SNSExecuteUsernameChange;

    Page *page1 = [[Page alloc] initWithPageNumber:1 parentPage:1];
    [page1 addItem:sessionItem];
    [page1 addItem:usernameItem];
    [page1 addItem:enterItem];

    [menu addPage:page1];
    [menu setUserDefaultsAndDict];
    [menu loadPage:1];
}

static void didFinishLaunching(CFNotificationCenterRef center,
                               void *observer,
                               CFStringRef name,
                               const void *object,
                               CFDictionaryRef info) {
    timer(4) {
        initMenu();
    });
}

%ctor {
    CFNotificationCenterAddObserver(CFNotificationCenterGetLocalCenter(),
                                    NULL,
                                    &didFinishLaunching,
                                    (CFStringRef)UIApplicationDidFinishLaunchingNotification,
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
}
