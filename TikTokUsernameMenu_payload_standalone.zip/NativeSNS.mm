#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonDigest.h>
#import <Security/Security.h>

#include "NativeSNS.h"

#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace {

static std::string safeCString(const char *s) {
    return s ? std::string(s) : std::string();
}

static char *copyCString(const std::string &s) {
    char *out = static_cast<char *>(std::malloc(s.size() + 1));
    if (!out) return nullptr;
    std::memcpy(out, s.c_str(), s.size() + 1);
    return out;
}

static char *copyNSString(NSString *s) {
    if (!s) return copyCString("");
    const char *utf8 = [s UTF8String];
    return copyCString(utf8 ? utf8 : "");
}

static std::string md5Hex(const void *bytes, size_t len, bool uppercase = false) {
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    CC_MD5(bytes, static_cast<CC_LONG>(len), digest);
#pragma clang diagnostic pop

    static const char *lower = "0123456789abcdef";
    static const char *upper = "0123456789ABCDEF";
    const char *alphabet = uppercase ? upper : lower;

    std::string out;
    out.resize(CC_MD5_DIGEST_LENGTH * 2);
    for (size_t i = 0; i < CC_MD5_DIGEST_LENGTH; ++i) {
        out[i * 2] = alphabet[(digest[i] >> 4) & 0xF];
        out[i * 2 + 1] = alphabet[digest[i] & 0xF];
    }
    return out;
}

static uint8_t reverseNibbles(uint8_t n) {
    return static_cast<uint8_t>((n << 4) | (n >> 4));
}

static uint8_t reverseBits(uint8_t n) {
    n = static_cast<uint8_t>(((n & 0xF0) >> 4) | ((n & 0x0F) << 4));
    n = static_cast<uint8_t>(((n & 0xCC) >> 2) | ((n & 0x33) << 2));
    n = static_cast<uint8_t>(((n & 0xAA) >> 1) | ((n & 0x55) << 1));
    return n;
}

static std::string byteHex(uint8_t n) {
    char buf[3];
    std::snprintf(buf, sizeof(buf), "%02x", n);
    return std::string(buf);
}

static uint8_t randomChoice0To254() {
    return static_cast<uint8_t>(arc4random_uniform(255)); // Python choice(range(0, 0xFF)) => 0..254
}

class XG {
public:
    explicit XG(const std::vector<uint8_t> &debug)
        : debug_(debug),
          ce0_{0x05, 0x00, 0x50, randomChoice0To254(), 0x47, 0x1e, 0x00,
               static_cast<uint8_t>(randomChoice0To254() & 0xF0)} {}

    std::string main() {
        auto debug = calculate(initial(debug_, addrBA8()));
        std::string result;
        result.reserve(debug.size() * 2);
        for (uint8_t item : debug) result += byteHex(item);

        return std::string("8404") + byteHex(ce0_[7]) + byteHex(ce0_[3]) +
               byteHex(ce0_[1]) + byteHex(ce0_[6]) + result;
    }

private:
    static constexpr size_t kLength = 0x14;
    std::vector<uint8_t> debug_;
    std::array<uint8_t, 8> ce0_;

    std::array<uint8_t, 256> addrBA8() const {
        std::array<uint8_t, 256> table{};
        for (size_t i = 0; i < table.size(); ++i) table[i] = static_cast<uint8_t>(i);

        int tmp = -1; // -1 mirrors Python's empty-string sentinel.
        for (int i = 0; i < 256; ++i) {
            int A;
            if (i == 0) A = 0;
            else if (tmp > 0) A = tmp; // Python: elif tmp: (0 is false)
            else A = table[static_cast<size_t>(i - 1)];

            int B = ce0_[static_cast<size_t>(i % 8)];
            if (A == 0x05) {
                if (i != 1) {
                    if (tmp != 0x05) A = 0;
                }
            }

            int C = A + i + B;
            while (C >= 0x100) C -= 0x100;

            if (C < i) tmp = C;
            else tmp = -1;

            uint8_t D = table[static_cast<size_t>(C)];
            table[static_cast<size_t>(i)] = D;
        }
        return table;
    }

    std::vector<uint8_t> initial(std::vector<uint8_t> debug,
                                 const std::array<uint8_t, 256> &hexBA8) const {
        std::vector<uint8_t> tmpAdd;
        tmpAdd.reserve(kLength);
        auto tmpHex = hexBA8;

        for (size_t i = 0; i < kLength; ++i) {
            uint8_t A = debug[i];
            int B = tmpAdd.empty() ? 0 : tmpAdd.back();
            int C = hexBA8[i + 1] + B;
            while (C >= 0x100) C -= 0x100;
            tmpAdd.push_back(static_cast<uint8_t>(C));

            uint8_t D = tmpHex[static_cast<size_t>(C)];
            tmpHex[i + 1] = D;
            int E = D + D;
            while (E >= 0x100) E -= 0x100;
            uint8_t F = tmpHex[static_cast<size_t>(E)];
            debug[i] = static_cast<uint8_t>(A ^ F);
        }
        return debug;
    }

    std::vector<uint8_t> calculate(std::vector<uint8_t> debug) const {
        for (size_t i = 0; i < kLength; ++i) {
            uint8_t A = debug[i];
            uint8_t B = reverseNibbles(A);
            uint8_t C = debug[(i + 1) % kLength];
            uint8_t D = static_cast<uint8_t>(B ^ C);
            uint8_t E = reverseBits(D);
            uint8_t F = static_cast<uint8_t>(E ^ kLength);
            uint32_t G = ~static_cast<uint32_t>(F);
            debug[i] = static_cast<uint8_t>(G & 0xFF);
        }
        return debug;
    }
};

struct Signature {
    std::string gorgon;
    std::string khronos;
};

static Signature makeSignature(const std::string &param,
                               const std::string *stub,
                               const std::string *cookie,
                               const void *rawData,
                               size_t rawDataLen,
                               bool useRawData) {
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    uint32_t epoch = static_cast<uint32_t>(now);

    char khex[9];
    std::snprintf(khex, sizeof(khex), "%08x", epoch);
    std::string KhronosHex(khex);

    std::vector<uint8_t> gorgon;
    gorgon.reserve(20);

    std::string urlMD5 = md5Hex(param.data(), param.size());
    for (int i = 0; i < 4; ++i) {
        gorgon.push_back(static_cast<uint8_t>(std::strtoul(urlMD5.substr(i * 2, 2).c_str(), nullptr, 16)));
    }

    if (useRawData && rawData && rawDataLen > 0) {
        std::string dataMD5 = md5Hex(rawData, rawDataLen);
        for (int i = 0; i < 4; ++i) {
            gorgon.push_back(static_cast<uint8_t>(std::strtoul(dataMD5.substr(i * 2, 2).c_str(), nullptr, 16)));
        }
    } else if (!useRawData && stub && !stub->empty()) {
        for (int i = 0; i < 4; ++i) {
            gorgon.push_back(static_cast<uint8_t>(std::strtoul(stub->substr(i * 2, 2).c_str(), nullptr, 16)));
        }
    } else {
        gorgon.insert(gorgon.end(), 4, 0x00);
    }

    if (cookie && !cookie->empty()) {
        std::string cookieMD5 = md5Hex(cookie->data(), cookie->size());
        for (int i = 0; i < 4; ++i) {
            gorgon.push_back(static_cast<uint8_t>(std::strtoul(cookieMD5.substr(i * 2, 2).c_str(), nullptr, 16)));
        }
    } else {
        gorgon.insert(gorgon.end(), 4, 0x00);
    }

    gorgon.push_back(0x01);
    gorgon.push_back(0x01);
    gorgon.push_back(0x02);
    gorgon.push_back(0x04);

    for (int i = 0; i < 4; ++i) {
        gorgon.push_back(static_cast<uint8_t>(std::strtoul(KhronosHex.substr(i * 2, 2).c_str(), nullptr, 16)));
    }

    XG xg(gorgon);
    return {xg.main(), std::to_string(epoch)};
}

static NSString *jsonForSignature(const Signature &s) {
    NSDictionary *obj = @{
        @"X-Gorgon": [NSString stringWithUTF8String:s.gorgon.c_str()],
        @"X-Khronos": [NSString stringWithUTF8String:s.khronos.c_str()]
    };
    NSData *data = [NSJSONSerialization dataWithJSONObject:obj options:0 error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

static NSString *ns(const char *s) {
    return s ? [NSString stringWithUTF8String:s] : @"";
}

static NSString *percentEncodeLikePythonQuote(NSString *input) {
    NSData *data = [input dataUsingEncoding:NSUTF8StringEncoding];
    const uint8_t *bytes = static_cast<const uint8_t *>(data.bytes);
    NSMutableString *out = [NSMutableString string];
    const char *hex = "0123456789ABCDEF";

    for (NSUInteger i = 0; i < data.length; ++i) {
        uint8_t c = bytes[i];
        bool unreserved = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                          (c >= '0' && c <= '9') || c == '_' || c == '.' ||
                          c == '-' || c == '~' || c == '/'; // urllib.parse.quote default safe='/'
        if (unreserved) {
            [out appendFormat:@"%c", c];
        } else {
            [out appendFormat:@"%%%c%c", hex[(c >> 4) & 0xF], hex[c & 0xF]];
        }
    }
    return out;
}

static NSData *performRequest(NSMutableURLRequest *request, NSInteger *statusCode, NSError **outError) {
    __block NSData *responseData = nil;
    __block NSURLResponse *response = nil;
    __block NSError *requestError = nil;

    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession]
        dataTaskWithRequest:request
          completionHandler:^(NSData *data, NSURLResponse *resp, NSError *error) {
              responseData = data;
              response = resp;
              requestError = error;
              dispatch_semaphore_signal(sem);
          }];
    [task resume];
    dispatch_semaphore_wait(sem, DISPATCH_TIME_FOREVER);

    if (statusCode && [response isKindOfClass:[NSHTTPURLResponse class]]) {
        *statusCode = ((NSHTTPURLResponse *)response).statusCode;
    }
    if (outError) *outError = requestError;
    return responseData;
}

__attribute__((used)) static const char kSourceLine207[] = "Retrieve the current TikTok username for a given session, device, and iid.";

static NSString *getProfileInternal(NSString *sessionID, NSString *deviceID, NSString *iid) {
    // deviceID / iid are intentionally unused here because the original Python get_profile()
    // hard-codes both values in the request URL.
    (void)deviceID;
    (void)iid;

    NSString *urlString = @"https://api.tiktokv.com/passport/account/info/v2/?id=kaa&version_code=34.0.0&language=en&app_name=lite&app_version=34.0.0&carrier_region=SA&device_id=7256623439258404357&tz_offset=10800&mcc_mnc=42001&locale=en&sys_region=SA&aid=473824&screen_width=1284&os_api=18&ac=WIFI&os_version=17.3&app_language=en&tz_name=Asia/Riyadh&carrier_region1=SA&build_number=340002&device_platform=iphone&iid=7353686754157692689&device_type=iPhone13,4";

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    request.HTTPMethod = @"GET";
    [request setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    [request setValue:[NSString stringWithFormat:@"sessionid=%@", sessionID] forHTTPHeaderField:@"Cookie"];
    [request setValue:@"2" forHTTPHeaderField:@"sdk-version"];
    [request setValue:@"com.zhiliaoapp.musically/432424234 (Linux; U; Android 5; en; fewfwdw; Build/PI;tt-ok/3.12.13.1)"
       forHTTPHeaderField:@"User-Agent"];

    NSError *error = nil;
    NSData *data = performRequest(request, nullptr, &error);
    if (error || !data) return @"None";

    id obj = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (error || ![obj isKindOfClass:[NSDictionary class]]) return @"None";

    id profileData = ((NSDictionary *)obj)[@"data"];
    if (![profileData isKindOfClass:[NSDictionary class]]) return @"None";

    id username = ((NSDictionary *)profileData)[@"username"];
    if (![username isKindOfClass:[NSString class]]) return @"None";
    return (NSString *)username;
}

__attribute__((used)) static const char kSourceLine226[] = "Check if the username has been changed in the TikTok profile.";

static NSString *randomDecimalID() {
    // Original: random.randint(777777788, 999999999999), inclusive.
    const uint64_t minV = 777777788ULL;
    const uint64_t maxV = 999999999999ULL;
    const uint64_t span = maxV - minV + 1ULL;

    uint64_t r = 0;
    if (SecRandomCopyBytes(kSecRandomDefault, sizeof(r), reinterpret_cast<uint8_t *>(&r)) != errSecSuccess) {
        r = (static_cast<uint64_t>(arc4random()) << 32) | arc4random();
    }
    uint64_t value = minV + (r % span);
    return [NSString stringWithFormat:@"%llu", value];
}

__attribute__((used)) static const char kSourceLine231[] = "Attempt to change a TikTok username.";

static NSDictionary *changeUsernameDetailedInternal(NSString *sessionID,
                                                       NSString *deviceID,
                                                       NSString *iid,
                                                       NSString *lastUsername,
                                                       NSString *newUsername) {
    NSString *encodedNew = percentEncodeLikePythonQuote(newUsername);
    NSString *bodyString = [NSString stringWithFormat:@"aid=364225&unique_id=%@", encodedNew];
    NSData *bodyData = [bodyString dataUsingEncoding:NSUTF8StringEncoding];

    NSString *parm = [NSString stringWithFormat:
        @"aid=364225&residence=&device_id=%@&version_name=1.1.0&os_version=17.4.1&iid=%@&app_name=tiktok_snail&locale=en&ac=4G&sys_region=SA&version_code=1.1.0&channel=App%%20Store&op_region=SA&os_api=18&device_brand=iPad&idfv=16045E07-1ED5-4350-9318-77A1469C0B89&device_platform=iPad&device_type=iPad13,4&carrier_region1=&tz_name=Asia/Riyadh&account_region=sa&build_number=11005&tz_offset=10800&app_language=en&carrier_region=&current_region=&aid=364225&mcc_mnc=&screen_width=1284&uoo=1&content_language=&language=en&cdid=B75649A607DA449D8FF2ADE97E0BC3F1&openudid=7b053588b18d61b89c891592139b68d918b44933&app_version=1.1.0",
        deviceID, iid];

    std::string bodyMD5 = md5Hex(bodyData.bytes, bodyData.length);
    std::string paramCpp = [parm UTF8String] ? [parm UTF8String] : "";
    Signature sig = makeSignature(paramCpp, &bodyMD5, nullptr, nullptr, 0, false);

    NSString *urlString = [NSString stringWithFormat:@"https://api.tiktokv.com/aweme/v1/commit/user/?%@", parm];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    request.HTTPMethod = @"POST";
    request.HTTPBody = bodyData;
    [request setValue:@"keep-alive" forHTTPHeaderField:@"Connection"];
    [request setValue:@"Whee 1.1.0 rv:11005 (iPad; iOS 17.4.1; en_SA@calendar=gregorian) Cronet"
       forHTTPHeaderField:@"User-Agent"];
    [request setValue:[NSString stringWithFormat:@"sessionid=%@", sessionID] forHTTPHeaderField:@"Cookie"];
    [request setValue:[NSString stringWithUTF8String:sig.gorgon.c_str()] forHTTPHeaderField:@"X-Gorgon"];
    [request setValue:[NSString stringWithUTF8String:sig.khronos.c_str()] forHTTPHeaderField:@"X-Khronos"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];

    NSError *error = nil;
    NSInteger statusCode = 0;
    NSData *responseData = performRequest(request, &statusCode, &error);

    NSString *responseText = @"";
    if (responseData.length > 0) {
        responseText = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
        if (!responseText) {
            responseText = [NSString stringWithFormat:@"(non-UTF8 response, base64)\n%@",
                            [responseData base64EncodedStringWithOptions:0]];
        }
    }

    NSString *networkError = error.localizedDescription ?: @"";
    NSString *current = getProfileInternal(sessionID, deviceID, iid);
    BOOL changedExactly = [current isEqualToString:newUsername];

    NSString *legacyResult = nil;
    if (changedExactly) {
        legacyResult = @"Username change successful.";
    } else {
        NSString *failureBody = responseText.length ? responseText : networkError;
        legacyResult = [@"Failed to change username: " stringByAppendingString:failureBody ?: @""];
    }

    return @{
        @"http_status": @(statusCode),
        @"response_body": responseText ?: @"",
        @"network_error": networkError ?: @"",
        @"api_result": legacyResult ?: @"",
        @"profile_before": lastUsername ?: @"",
        @"requested_username": newUsername ?: @"",
        @"profile_after": current ?: @"",
        @"changed_exactly": @(changedExactly)
    };
}

static NSString *changeUsernameInternal(NSString *sessionID,
                                        NSString *deviceID,
                                        NSString *iid,
                                        NSString *lastUsername,
                                        NSString *newUsername) {
    NSDictionary *detail = changeUsernameDetailedInternal(sessionID, deviceID, iid,
                                                          lastUsername, newUsername);
    return [detail[@"api_result"] isKindOfClass:[NSString class]] ? detail[@"api_result"] : @"";
}

} // namespace

extern "C" {

char *sns_run(const char *param, const char *stub, const char *cookie) {
    @autoreleasepool {
        std::string p = safeCString(param);
        std::string s = safeCString(stub);
        std::string c = safeCString(cookie);
        const std::string *sp = s.empty() ? nullptr : &s;
        const std::string *cp = c.empty() ? nullptr : &c;
        Signature sig = makeSignature(p, sp, cp, nullptr, 0, false);
        return copyNSString(jsonForSignature(sig));
    }
}

char *sns_x_gorgon(const char *param, const void *data, unsigned long data_len, const char *cookie) {
    @autoreleasepool {
        std::string p = safeCString(param);
        std::string c = safeCString(cookie);
        const std::string *cp = c.empty() ? nullptr : &c;
        Signature sig = makeSignature(p, nullptr, cp, data, static_cast<size_t>(data_len), true);
        return copyNSString(jsonForSignature(sig));
    }
}

char *sns_get_stub(const void *data, unsigned long data_len) {
    @autoreleasepool {
        if (!data || data_len == 0) return copyCString("00000000000000000000000000000000");
        return copyCString(md5Hex(data, static_cast<size_t>(data_len), true));
    }
}

char *sns_get_profile(const char *session_id, const char *device_id, const char *iid) {
    @autoreleasepool {
        NSString *result = getProfileInternal(ns(session_id), ns(device_id), ns(iid));
        return copyNSString(result);
    }
}

int sns_check_is_changed(const char *last_username, const char *session_id, const char *device_id, const char *iid) {
    @autoreleasepool {
        NSString *current = getProfileInternal(ns(session_id), ns(device_id), ns(iid));
        return ![current isEqualToString:ns(last_username)];
    }
}

char *sns_change_username(const char *session_id,
                          const char *device_id,
                          const char *iid,
                          const char *last_username,
                          const char *new_username) {
    @autoreleasepool {
        NSString *result = changeUsernameInternal(ns(session_id), ns(device_id), ns(iid),
                                                  ns(last_username), ns(new_username));
        return copyNSString(result);
    }
}

__attribute__((used)) static const char kSourceLine262[] = "Enter session ID of an ARAB TikTok account: ";
__attribute__((used)) static const char kSourceLine265[] = "#tiktokthailand ";
__attribute__((used)) static const char kSourceLine266[] = "Your CURRENT TikTok username is: ";

char *sns_change_username_auto(const char *session_id, const char *new_username) {
    @autoreleasepool {
        NSString *session = ns(session_id);
        NSString *deviceID = randomDecimalID();
        NSString *iid = randomDecimalID();
        NSString *lastUsername = getProfileInternal(session, deviceID, iid);

        if ([lastUsername isEqualToString:@"None"]) {
            return copyCString("Invalid session ID or other error.");
        }

        NSString *result = changeUsernameInternal(session, deviceID, iid, lastUsername, ns(new_username));
        return copyNSString(result);
    }
}

char *sns_change_username_auto_detailed(const char *session_id, const char *new_username) {
    @autoreleasepool {
        NSString *session = ns(session_id);
        NSString *requested = ns(new_username);
        NSString *deviceID = randomDecimalID();
        NSString *iid = randomDecimalID();
        NSString *before = getProfileInternal(session, deviceID, iid);

        NSDictionary *detail = nil;
        if ([before isEqualToString:@"None"] || before.length == 0) {
            detail = @{
                @"http_status": @0,
                @"response_body": @"",
                @"network_error": @"",
                @"api_result": @"Invalid session ID or other error.",
                @"profile_before": before ?: @"None",
                @"requested_username": requested ?: @"",
                @"profile_after": before ?: @"None",
                @"changed_exactly": @NO
            };
        } else {
            detail = changeUsernameDetailedInternal(session, deviceID, iid, before, requested);
        }

        NSError *jsonError = nil;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:detail options:0 error:&jsonError];
        if (!jsonData || jsonError) {
            NSString *fallback = [NSString stringWithFormat:
                @"{\"http_status\":0,\"response_body\":\"\",\"network_error\":\"%@\",\"api_result\":\"detail serialization failed\",\"profile_before\":\"\",\"requested_username\":\"\",\"profile_after\":\"\",\"changed_exactly\":false}",
                jsonError.localizedDescription ?: @"unknown error"];
            return copyNSString(fallback);
        }

        NSString *json = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return copyNSString(json ?: @"{}");
    }
}

void sns_free(void *ptr) {
    std::free(ptr);
}

} // extern "C"
