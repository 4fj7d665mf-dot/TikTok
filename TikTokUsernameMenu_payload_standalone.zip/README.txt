Standalone direct-injection build.
No Logos hooks and no CydiaSubstrate/MobileSubstrate dependency should remain.
Build workflow must clone xelahot/iOS-Mod-Menu-Base first, then overlay these files.

Build compatibility fix:
- Minimum deployment target raised to iOS 14.0 for arm64e.
- StandaloneEntry uses UIWindowScene only (no deprecated UIApplication.keyWindow/windows).
- Deprecated declarations in the upstream xelahot Menu.mm are tolerated because the standalone entry reparents the menu to the active scene window after init.
