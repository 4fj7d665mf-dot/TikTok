Standalone direct-injection build.
No Logos hooks and no CydiaSubstrate/MobileSubstrate dependency should remain.
Build workflow must clone xelahot/iOS-Mod-Menu-Base first, then overlay these files.
