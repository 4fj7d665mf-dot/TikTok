TikTokUsernameMenu standalone dylib payload - result screen build

Changes in this build:
- Detailed result screen after Enter.
- Shows HTTP Status, Network Error, API Result, TikTok Response Body,
  username before, requested username, and current username after verification.
- JSON response bodies are pretty-printed when possible.
- Result dialog includes a Copy button.
- Session ID is intentionally NOT included in the detailed result JSON or result screen.

Build with the same GitHub Actions build.yml used for the standalone payload.
Upload this zip as: TikTokUsernameMenu_payload_standalone.zip
