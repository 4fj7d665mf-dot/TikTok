#import <UIKit/UIKit.h>

#import "Menu.h"
#import "Page.h"
#import "TextfieldItem.h"
#import "InvokeItem.h"
#import "Utils.h"
#import "NativeSNS.h"
#import "SNSFlow.h"

#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)((sec) * NSEC_PER_SEC)), dispatch_get_main_queue(), ^

static Menu *menu = nil;
static NSString *gCurrentUsername = nil;
static NSString *gCurrentSessionID = nil;
static BOOL gBusy = NO;
static BOOL gMenuInitialized = NO;

static UIImage *SNSBundledMenuIcon(void) {
    static UIImage *icon = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *encoded =
        @"/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/"
        @"2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wgARCACgAKADASIAAhEBAxEB/8QA"
        @"GwAAAQUBAQAAAAAAAAAAAAAAAQACAwQFBgf/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIDBAUG/9oADAMBAAIQAxAAAAH0oAOSTUBAAiGpogAC1NBwiQ5Ewg8t"
        @"AOTUO41NQQGicGhpwAYQGpECqS4iShn5/W910XlXTWcrsE1W8coILbU1BamicA0TgGseGsB2JpSl3lLN/tM/oPPo/TIJ5J315reMS1CtNMSHABopoBpqgncr"
        @"ysIWBAAnQYJ4aRxl9clYLSKzTtUwM8UUGyCV3B0qWou0pLMOfbHnOl53Tov18u/ykY9nY5nTvjq1rIsyp1eUduOmyix6k5Ul1J5na83okj5/qO/UsLd5XU+c"
        @"Fevi9J2uZh2oVXeo846K7P6Ix0OzzrxRuF1V8sHmNzqurQrq4rsIdqevFt34rcGbbhMbeWj79ehPKqnruVXr8z7He0pUOoWm389kFiZX3K1gRzZ1iKv53ZcN"
        @"FmGV+Gopt0tXV7MaF/nbW17Iz3acl3MVOjVr3Ar8RTSRtMc0dC8ECjeksLVnDlVzduOq7E0bL65IEaclTK6Cnm2walS1bQUFZVaa5pIAoiGloJBCQQAhIE0o"
        @"ZQQIEAkmh//EACcQAAICAQQBBAIDAQAAAAAAAAIDAQQABRESExAUISIwIDEGI1BA/9oACAEBAAEFAv8AAIxGBKDjzvm/3anZOy3S7XphpatFtv8AwWT60Pfv"
        @"WAtsr2Jrtpawxz/u3zU2QVJrJOEpc7C05/BJt0+yB8x+rfwRQMCHZjFixcaFY71IFI41K2wE7fURQOQW8YyOU+d/LB3gS5j5IojN/wAGT/dOyj3jYNywmxE9"
        @"viSiM/fkPiflqO2UqJMYZ/KDIlPiZBZTMdY9rSkQdqFyMp3ot0RtRAs1WmD+I8RKCjCMQbE7+bCibChIAlu8yrlPVvjobxVaFmV/cNT58PSVmDWTClkUTlui"
        @"ZDRJ1GlRKCT4kNsid4yS4xAS3CARwJghL9BBHB1i5V9urW7Bgt4WapVbpoY/VUiJau2MPURaGjsWyvk+0cvgEbBLD7XvHo7Paw521K7OzWc6qrUNt1zligmO"
        @"/wDkCS33wv3XOVnasstGXtmhMIbeMnYGCyUi0TwR+bdmN9NtjkgMPqGl1TkUdEKyLAwI8wsMkYXY0V0ErSX7vqOqzyyffNIqf25aKYEiOJCDc1yp7B9mCW+X"
        @"avqgRRheREDE5xHCiJIYgz8EMTjNMqMlenVVzhnwhQTkowAhY48JMRPbOXty9onfOUFkn7/Jkyti8G8M5yifMltjb4DiQmY/GZVYwd9u7jhP5YJQWElk5EwA"
        @"L5cGDg9Ds9O+M6GYaa65QHOPxnfGVe7zIxOMWwLC5KclEc3dvARnF1hCfD0yyNxAVWD+0wg4ABXH4NRyKayZL/L/AP/EACgRAAIBBAECBgIDAAAAAAAAAAEC"
        @"AAMREiEEIjEFEBQwMkETIFFhcf/aAAgBAwEBPwH9rffsqLm0HHVqP4iNTm+GkHKiNexRZUcMfqVvEKY+EHiI+LjUYWP6lNAwSx873HnYntBhjuLTLJYSkgar"
        @"gZ6Gpn1HUrcchcqYnpWCZNBLQ0jqUlLbEq8dke0qZJ1jtOGA1cZRlsu4lHtrU5qXpkCL3lSniICHF4r9VjqcvkDHEbjMr7aMo+UHiT/cp+KLbqnI54cWWKMe"
        @"oxqww13itibiXWp/RnpyYKKqeozkFqf+SrQSwYCYU/5lFKeJcx3LG58yby5EZ795S5BUjLcr8ovodvLjcnEYP2lVkY9It7n/xAAmEQACAgEEAQMFAQAAAAAA"
        @"AAABAgADBBESITEQBRMwICIyQVFA/9oACAECAQE/Af8ABv51iv8A34DBWT3Pb+US21UG5zLM1jadrcSrIS38THbQax8tNvHcx8kE6OYtqtwPKZFbsUB5l+0j"
        @"a/RjU6cTGrrT7VGhlnUIBgpUSgBW85OPZW5f9SvJZ9N7cTIvD8LEz7EGkpyrb3Caz2hDT/IlWnllDLtMv9Mes/Z1Nrr+omNdZ0J6fRUOVHIlV24lT4ssIIUf"
        @"SQD3AAOBHqDDSU44Tk9+LqN53DuVqw/I/J//xAAzEAABAwMCBAUCBgEFAAAAAAABAAIRAxIhMUEQIlFhEyAycYFSsQQwQEJQkaEzgsHR8f/aAAgBAQAGPwL+"
        @"AlxA91LTI7fo5E+E0wO6qzc+fSwLw3MsO2f0NR/RqpUbS23KlCo0AlvVNpVGN5sSP0FQNdKlxk6KKbC5CKBDgNQ7UoOLD/uCDuon80k7Kanw1OpkcpEK1zmm"
        @"l9UoNa2AOEPYHK067d/ypdAUjgxu0yfPj1DRB3kyQPLTG2f7V8crvV/2pxCudvoOijLj0C5g9vuOGfI4beryTcQdOqtL7m7Y04OuJAb0XiF8GJhCMOnHuuYQ"
        @"d0GtbG7k5wGQnPoFgosdHcrxakNPpKFwd7wrKriT7SAvEoxnONCgRvwbcQJBXXiIdCtc+89VDB87K4vJOiEk4XIboyJUaO6FX/WZTS0f+ol7X06h1ITGNeCx"
        @"mmN0IGiLKdKm7JcHbrw3NDnZ/dom2ukAcbmYP3U8JKuqTGzVyQHdOqkcJugK+m/niOYJo3bgplCn6quEGVHGYmA5TJt3CFh8Q9FmkGq1/iI2YzkdOBV3aU0d"
        @"k6NtuqfmD0OvBjqYFuTVJQY53NtOie5uDCf+HbTwwf6g1QKe3sCqVYekcqnXgKgiR1V1UzGnCP2uEcHeyaxmwHytY7LWKn7u6p0yN7j8Lkc5vZXVOdx5QrKb"
        @"/EPbYp9+Zj+91ab7exVtNpPQAJry4XVMGNuyc58v+FNAgt6FC9kGcuuRuabfqHHxwCGNGCdXcIbv9t1hlzexVz2ta1m25V9gd9wg4sc3EZ4ANdBCg/KgaLK0"
        @"QPQyotORvxypNIfCltFnzwlF7vUf8Lke5nsrRPzwxqDKgiD0UqVPCBoj4cQNyrmkOO8/8IXcs9Vt5CGAvI1jQIVanrO3TzS1+W/4UuBDToV29lqF6mowPlCw"
        @"1B2BQv1VamIMGQhb4jJ3GBK5fxP9sXNXcfYQpeHvOuSSmNGj8n2182Fzvd8COOQCi1lN3hvhxLPss07OmVd8xsrnNf7XbqxjRd9kHHmeN+Mt9X3QfJZbieil"
        @"0VGfU3b82CoaPKXNjIggq402z/Gf/8QAJhABAAIBAwUAAgMBAQAAAAAAAQARITFBURBhcYGRobEg4fDB0f/aAAgBAQABPyHpcXrcuX0vpfmXL6X0vpcuXLly"
        @"5fR6XLlSLypXDzLoMvqMWLL630voxlyqgY+y3juGAahcv6me07lwl+Y9L6XLixZfS4suX3JlSrG4yWdd73vGprp0vWbZeNEpJFTZej19x6LLi1zL7y/DL/1z"
        @"MbXiqhzlRdcXADwCzxMKzk0+yhZ4hSzWntL1w21zeoA10QuX0+S4suXLl+pb/mYcz39lDVC1lEKhzbg88s1cSBHkRcjJPEDsCjEq+JS9a0xVfgZcOtxY+Z8n"
        @"qfZ+YJYHfEIlE7Mt7y7dXkVn91L7y7Np8nZ0+xLa6nlDANT50Jc/LxKOk+dHPMyfKGY/zmGkBioYHaKs+C7uVtL4Eoc4rdeZTZdLwT7CbQHLBBZVdG4OTYe9"
        @"YdaghmzR4jTgDB/p0JKiKFW2sOuwx0PMqaULrpCOw8CXghtaVxXd/UtYAoVH1AXwqaqaxMOVXovaAN+i9CN9AbKOFZxTssyNAs6YiRZ9QDY07MvzGCx1bzdP"
        @"yCKRwzGc2ML0P/YmFjYBEAcNUU6UgBmzvKHtUqbmdVtPTQguBC90DZdR3ZVkujogyVuvMKNFMvMHFNBDPZYTOVF4dniXgUDfO/ShdD5Cv3CtIMzolxYSJQFs"
        @"3Gc24DvywN0y6tfEM5BzBazUJC3kALe8Ci6gCk/97x7KFTsk1q21cce4cduBRA7dObNkVLEqmK8xKjXTDf5mkA6ghc1Aj+i6NUZQuV7cGUwgjBZVT1cy3Yxn"
        @"vJRVcWVvDrJEZd7dxjm5jye3aNZrOHZmKDUsA1vEe5yL4agDav7p/wAiLJyOzrMnKzrcO3eWenspZBgEKAUBDayMhdhedSXL1wv1GxBueFYhWLNL4R4qZq0G"
        @"r/DECUsH+cxV67giH2arwBi1cTtOe+AHsKF2aQJyzpdg4qAqvil/LBU2OoMLIsWaovDxUXuWbaSCw6qNnYN4bKvgMSrm474mPRoWkdfkub5mXjQtr5LedVjk"
        @"+RujStTd3aYEFD+iFdaya87TJ0iAF+rLIILbotLhEwGhK1hc3GGTpUDxD1WxvjvRNuOmiiVpn0/UPWRuL/cADaBavsGrBPc/ZwQbWz2WPjpDuFratXllwHxQ"
        @"57R8xRdjMq5o9wQRomdTjzCyjuiVRYbKzBCt8cMRi9ps03DSMKf5lwBa17iIHXRg5WOrYXwn10vo45ljydNfIdpXsFGccpG1bc6toSpseZeATel2/JQspdJ1"
        @"jnlg013xtNWd8KxA2/rmvsytuuNBQ3CdqDfMKKGAWwJzxCxZKvxfqepcvvPnQodDswqNo3JVxfE00I5h9CTYO4DYU22NIdpTQh/UfS5vunmEKyDKNPYEegG6"
        @"sHlHTdAtvBF6XEwK7DicYAH4TUhS3WHKS7/g9PX8H3LljGrGxpGUwF5eX+Ppjle/meWHqrnqfJf8MT5Hp9ly5fS/EvOOmenuacRel94svr7nyPiadL632jLl"
        @"yzp//9oADAMBAAIAAwAAABCGkkkVUv6WwEa4Tf564jW1UeQzACW/2/UiLJ+4xNa9EXMsrlyPbusGLRJUnPdCFpJgyNeCCEGYfPhg3gog9m1jfIGlLxkIN9Pp"
        @"pZb/xAAmEQEAAgEBBwQDAAAAAAAAAAABABEhMRBBUWGBkfBxobHRIMHh/9oACAEDAQE/EHYuy5ctWGPwZcuXLimdXExmfKnXr+4ixJbnfvrZcXYy9mVyw9mA"
        @"ixxE3YWpcwGx2Moua+fqKszfVN8FGaDhCMG1BANXp5rFOam+Z/ILXGmYk0M+sIJVaTlxioNVpGDmOFkG711pzjSmlY9fMwKihfmGtcmtJxaZ61Z7xRtfGCYD"
        @"xwmj6s9oLBFt4vbhCpchy1rvGCpbVrMWEtxmHXviAMKAOHzrKdAe/wBzGCozPWJ7SNpW3Jv67e0YdYhlPMPqOmOv8lArOfzAgEy03vrLtAS2s1EM59GVhaOO"
        @"Bngg2OsSgwRYxDUIWArXccpuP+XrKgNk8Yhh2R2Mr8//xAAlEQEAAgEDAwMFAAAAAAAAAAABABEhEDFRIEFxMGHwgZGhwfH/2gAIAQIBAT8Q0qBrWpoErowk"
        @"aAsx0qHRsSMRi2MqtCGhTjSnpwTNRMAOZbENHbtCrulnvqZ0vltEZjF3+otbcNMQBuTDw8nzfiO77OCXNEPKnmWHUsCsQLOWYQb6HBFddLbe/wAuPBOcwf8A"
        @"WY/F52YYVS5/v5mW4l5Szaw5hhjobGNnPs9vMUZy+d5mY5O7SvPeveXoLH7wubxLDbVbglC4BQEYjF8Yz7zvJorFqC0s0PS//8QAJBABAAICAgMBAQEBAQEB"
        @"AAAAAQARITFBUWFxgZGhscHh8PH/2gAIAQEAAT8Qv1+xQm+25g5inGJfiPsRRr+xVcfJZX/sejnyxV7/AGYsNtYiLzSwTGH9hTnMv3MeGOtkfb8luyfEpx/s"
        @"fqNOMxtzFtz/ALFe7ivf6RtsPyIvQfZwuHAIJdGiwfsXewljh/ZTxiIzivc8Gjyx4rj3PI+onNx8mK9xd3Vdx6NRWsZ8xAS3x+xLsX7EcjGnLbwxhQkqF28s"
        @"vPC/oxEOA2YAq9WUMLr3USmmvDG26eIq5fyLZbXoI8kD5FIgav8As/f2J1ORUZ2UYub0e4rhaiOt91EGgvtGUL2f2EpRVHTUQQiioas7OH+ytFCKkdKsph7C"
        @"QBUoma6uARHFRTs6g4u7ib0/su+/2LQxYT89S30eoPYfJ4JF4e0ybV9Im8nguPQT4igq08WMZaGziiY6ABswXkx1D8ZMrQoPkHbYyVD2sQgJBkBFaOFHMbox"
        @"YK9YOHixgfioFNJZ/sen7UGzZXdyysEL6fjOwYk7vyxzrH7GmzHGJY0nhOgK5qHgoni4tYLPhUakosVQRrfFnB4f2Voh9ljVAJx55li4fp0bDxDuaAAFQKzb"
        @"2QCZoB0nJ0yx5sL/APFmLmu5b14m2bMcToYs6X2kV8vLH9eI0dn3Fxk/FR4FcoB9YvF5E2/sKOH2E70zocICboPzicRZ6qoov/qUul8uLwZ75gnJ9E2bN6cO"
        @"Hw6fcWlV1Llcj5Gz5Btqlir/APZyz/JQoq1bq/2ALyHnMs7hctAkVrrGbBEDcQFX8YLAbRD2B9F9Rw4ODYrd3Gyp5OF8Nvbt6wcSgFVvPNaPsGS2IBZ+xQ+y"
        @"6vP2S1/OFCDHS5G7g43+MsKpfsolbQetB+l/ZthPyCGaHzUV1n9hKTbVCm6ViAAHOQLyGX0OItXivRA1gr03ZVfnyOJIcrFYDlTd94qXmHXCd+Ku4XJPJL7H"
        @"kYqYRBpQ44Dko0puRyDIYxKdROOW22bTRUveUlsHCPNlEDFBXMqy4zUtVavRK/LtQcJDECnrvUhjPCZI4AI3hi4V/wBjTSguhpW4BOphsGCf/UQdPyM3mQcg"
        @"5sNnGZWotXojzu/cQZGr4HByjmsHcM6ehAu9B/2EYFEMCzV4zKyXDASyhjsyc7htCy0RGzMrXlwXRUPw/rH0Yl3BVtgOS+Gu4TBOGvmtif7F+d3il5ulnFXD"
        @"numjKlHwoG5KG0HXBKJgml2S1OG/srzxiWHTFlXrOoZow+4mKyCX0d/5GRhlgUfSd+dzMKIemI9xrTydBuF2DgbgNdnWjUfWVYQen/D3Fnp0eiYlRWVYtMtt"
        @"F2vQ9RBhJ294BB7TCtGXnCT/AL5ubDDyW4VfJz4PMOOgM+atHGtQrYBGxnfPmOfpA4PKoABF2xOzR/IwRa/h1YDTOvousQDwo/bnGn4wx1AC0KE7k/mq4XJY"
        @"L4allQgwKNr6LdHGJcCKMcYWVzjkxBjZRAiukWreXhsGiuCnxUqzMNZ+Vi08UsxUjoyY2J2S+iwtaXZ5vSYfJEPc3AVEh5q4pbYxCs5P4jVANImZD9/4S7J5"
        @"CVq/Y7Q26AZuGFQ0LPIylxGewwSkTDAy05xU/TDEpnP2IymXvyizeLOX2dDTcGJq2U7Ym7lRFYFk2/CtOtkyakDYMF9WPyIh2qdUwooTIl4gYNVADlzsLhiw"
        @"qB0Lhtym1NcynQmsnrR5MEzzLiuBDNHh+QHIRkfAgB9hkwkK5gmtU55VmdNyJd7Gh/sed1MgdNUke7YINMooFDKN08kFAlcNOLrT7jplkrgYObxCUca6Islp"
        @"WQJvEdBF+agAlYZZAoc1h9jxcA0X1/oyhmlVU2dAHQt8zYNikGPLdnncxjBiGw4CujMY0wGXQcK8WukbK3Mboo/YxmvBCAbQYA8QXUA4S400K3nUIxPoAV/Y"
        @"ukIsmCAbS2C1qFFC6YK/5NAtg91bMGg6qOUZtbX/AIhbmpjH6cwEBTRxUaguNg6PM0Y4C7A14jntlMdsZ+bD4qXpgquNlR2rCn/1zDsIzBWxt5F/kZvzRgXV"
        @"pC10DFVzBDYTngmUKecRAArhSkVWqUtxDKhnQcnQ3RV+WX6qBNuB0z3uENUNIHq8Pxhwos3c4G/GkSc59xdSeYQOXVLemH25XokrSmg7p3H0rxBNVUaZaleH"
        @"5MSumZjmNBUDmsi289RjbNg5HAyWUnhgGK6FJ5zqAdZ9FULlGtBub6G4ULwDOoEQBqTNtMLtvzKR0VpTWcXWLqrrmLq/QUK1+LYmA2zQgwU4y2aqOto6EoeU"
        @"SWvmAX+LNIaaDasXQvxGoVyqKFVDFOKPcOVS+pQq6/JtgTHNps4hMrzIXT3XMcu3vXk8rRhIGBUGN1UPLPtxOcwUghH8caVyCS6kt2mDaxEIOkVPWn7FrRWW"
        @"KORYszS05jVogI5qtkWqiB0WfZK/+WX+80y5TwH9YlZuvMu9IfJQ8IZdL2/+eYsKBdolQV4sLHqDGggK6AwndV6mLF+4XV0y01YS78V4jrqX1Xyaz/M3s/It"
        @"N0leYOML5ZgYKdyhnJCJFDSBsR4YouBS7R2ryxo0f2Xn/lxVazfAQ5sajAgsEmKg1o/jzqCGAim5dtYfsUdj9gh06zN6x/yODK/ke8VEHIFeWINAHtzOMPwR"
        @"PivyWOaLPMHkYV3iPLMBw/yKrQj8mGP3KWoX7hlqy+7mBY59y3zfccPTzLtn9TA2GemNmW/2Kq9vMpM0+WPR/kbd0/IpfJ7m+H2OMJCrf9RUW2RVTdepZ2Id"
        @"EUSrYXimwmXCIuj63Nml/Y04ZwW2xc4f2f/Z";
        NSData *imageData = [[NSData alloc] initWithBase64EncodedString:encoded options:0];
        icon = imageData ? [UIImage imageWithData:imageData scale:[UIScreen mainScreen].scale] : nil;
    });
    return icon;
}

static UIWindow *SNSActiveWindow(void) {
    UIApplication *app = [UIApplication sharedApplication];
    UIWindow *fallback = nil;

    // This standalone build targets iOS 14+, so use the scene API only.
    // UIApplication.keyWindow / UIApplication.windows are deprecated and the
    // current Xcode toolchain promotes those warnings to errors.
    for (UIScene *scene in app.connectedScenes) {
        if (![scene isKindOfClass:[UIWindowScene class]]) continue;
        if (scene.activationState == UISceneActivationStateUnattached) continue;

        UIWindowScene *windowScene = (UIWindowScene *)scene;

        // Prefer the key window belonging to the foreground-active scene.
        if (scene.activationState == UISceneActivationStateForegroundActive) {
            for (UIWindow *window in windowScene.windows) {
                if (window.isKeyWindow) return window;
            }
            for (UIWindow *window in windowScene.windows) {
                if (!window.hidden && window.alpha > 0.0 && window.windowLevel == UIWindowLevelNormal) {
                    return window;
                }
            }
        }

        // Keep a visible window as a fallback while the scene is transitioning
        // between inactive and active states during application startup.
        if (!fallback) {
            for (UIWindow *window in windowScene.windows) {
                if (!window.hidden && window.alpha > 0.0 && window.windowLevel == UIWindowLevelNormal) {
                    fallback = window;
                    break;
                }
            }
        }
    }

    return fallback;
}

static void SNSAttachAndExposeMenu(void) {
    UIWindow *window = SNSActiveWindow();
    if (!window || !menu) return;

    UIButton *button = [menu getMenuButtRef];

    // The upstream base expects an external PNG under /var/mobile/Documents.
    // Our dylib must remain usable without that asset, so give the launcher a
    // visible fallback appearance unconditionally.
    if (button) {
        button.frame = CGRectMake(MAX(12.0, CGRectGetWidth(window.bounds) - 66.0), 70.0, 50.0, 50.0);
        button.layer.cornerRadius = 25.0;
        button.layer.masksToBounds = YES;
        UIImage *menuIcon = SNSBundledMenuIcon();
        if (menuIcon) {
            button.backgroundColor = [UIColor clearColor];
            [button setTitle:nil forState:UIControlStateNormal];
            [button setImage:menuIcon forState:UIControlStateNormal];
            button.imageView.contentMode = UIViewContentModeScaleAspectFill;
            button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentFill;
            button.contentVerticalAlignment = UIControlContentVerticalAlignmentFill;
            button.imageEdgeInsets = UIEdgeInsetsZero;
        } else {
            button.backgroundColor = [UIColor colorWithWhite:0.05 alpha:0.82];
            [button setImage:nil forState:UIControlStateNormal];
            [button setTitle:@"X" forState:UIControlStateNormal];
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            button.titleLabel.font = [UIFont boldSystemFontOfSize:22.0];
        }
        button.layer.zPosition = 100000.0;

        if (button.superview != window) {
            [button removeFromSuperview];
            [window addSubview:button];
        }
    }

    // If upstream Menu.mm saw a nil/deprecated keyWindow, its initial frame is
    // off-screen. Reposition and reattach it to the active UIWindowScene.
    menu.frame = CGRectMake(MAX(8.0, CGRectGetWidth(window.bounds) - 212.0), 130.0, 200.0, 250.0);
    menu.layer.zPosition = 99999.0;
    if (menu.superview != window) {
        [menu removeFromSuperview];
        [window addSubview:menu];
    }

    [window bringSubviewToFront:menu];
    if (button) [window bringSubviewToFront:button];
}

static NSString *SNSStringFromOwnedCString(char *raw) {
    if (!raw) return @"";
    NSString *value = [NSString stringWithUTF8String:raw] ?: @"";
    sns_free(raw);
    return value;
}

static NSString *SNSTrim(NSString *value) {
    return [(value ?: @"") stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

static UITextField *SNSFindTextField(UIView *view) {
    if ([view isKindOfClass:[UITextField class]]) {
        return (UITextField *)view;
    }
    for (UIView *subview in view.subviews) {
        UITextField *found = SNSFindTextField(subview);
        if (found) return found;
    }
    return nil;
}

// Read the visible UITextField directly so tapping the Enter menu item also works
// even if the keyboard Return key was not pressed first.
static NSString *SNSLiveTextfieldValue(NSString *title) {
    if (!menu) return @"";

    UIScrollView *scrollView = menu.ScrollViewRef;
    for (UIView *itemView in scrollView.subviews) {
        NSString *itemTitle = nil;
        for (UIView *subview in itemView.subviews) {
            if ([subview isKindOfClass:[UILabel class]]) {
                itemTitle = ((UILabel *)subview).text;
                break;
            }
        }

        if ([itemTitle isEqualToString:title]) {
            UITextField *textField = SNSFindTextField(itemView);
            if (textField) return textField.text ?: @"";
        }
    }

    return [menu getTextfieldValue:title] ?: @"";
}

static void SNSShow(NSString *title, NSString *message) {
    dispatch_async(dispatch_get_main_queue(), ^{
        showPopup(title ?: @"TikTok", message ?: @"");
    });
}

extern "C" void SNS_OnSessionEntered(NSString *sessionID) {
    NSString *session = SNSTrim(sessionID);
    if (session.length == 0) return;

    // Avoid duplicate calls caused by Return -> resignFirstResponder -> didEndEditing.
    if (gBusy) return;
    if (gCurrentUsername && [gCurrentSessionID isEqualToString:session]) return;

    gBusy = YES;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *username = SNSStringFromOwnedCString(
            sns_get_profile(session.UTF8String, "", "")
        );

        dispatch_async(dispatch_get_main_queue(), ^{
            gBusy = NO;

            if (username.length == 0 || [username isEqualToString:@"None"]) {
                gCurrentUsername = nil;
                gCurrentSessionID = nil;
                showPopup(@"TikTok", @"現在のUsernameを取得できませんでした。Session IDを確認してください。");
                return;
            }

            gCurrentUsername = username;
            gCurrentSessionID = session;
            showPopup(@"現在のUsername", username);
        });
    });
}

static void SNSExecuteUsernameChange(void) {
    if (gBusy) {
        SNSShow(@"TikTok", @"現在処理中です。");
        return;
    }

    NSString *session = SNSTrim(SNSLiveTextfieldValue(@"Session ID"));
    NSString *newUsername = SNSTrim(SNSLiveTextfieldValue(@"New Username"));

    if (session.length == 0) {
        SNSShow(@"TikTok", @"Session IDを入力してください。");
        return;
    }
    if (newUsername.length == 0) {
        SNSShow(@"TikTok", @"新しいUsernameを入力してください。");
        return;
    }

    gBusy = YES;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        // If the user tapped Enter before the automatic profile lookup completed,
        // obtain the current username here so the requested flow still completes.
        NSString *before = nil;
        if (gCurrentUsername && [gCurrentSessionID isEqualToString:session]) {
            before = gCurrentUsername;
        } else {
            before = SNSStringFromOwnedCString(
                sns_get_profile(session.UTF8String, "", "")
            );
        }

        if (before.length == 0 || [before isEqualToString:@"None"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                gBusy = NO;
                showPopup(@"TikTok", @"現在のUsernameを取得できませんでした。Session IDを確認してください。");
            });
            return;
        }

        // NativeSNS keeps the original Python flow: random device_id/iid,
        // change API, then profile re-check.
        NSString *apiResult = SNSStringFromOwnedCString(
            sns_change_username_auto(session.UTF8String, newUsername.UTF8String)
        );

        // Final exact verification: re-read the profile and compare it with the
        // requested username.
        NSString *after = SNSStringFromOwnedCString(
            sns_get_profile(session.UTF8String, "", "")
        );

        BOOL changedExactly = [after isEqualToString:newUsername];
        NSString *message = nil;

        if (changedExactly) {
            message = [NSString stringWithFormat:
                @"変更成功\n\n変更前: %@\n変更後: %@",
                before, after];
        } else {
            message = [NSString stringWithFormat:
                @"変更を確認できませんでした。\n\nAPI: %@\n現在: %@",
                apiResult.length ? apiResult : @"(no response)",
                after.length ? after : @"取得失敗"];
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            gBusy = NO;
            gCurrentUsername = (after.length && ![after isEqualToString:@"None"]) ? after : before;
            gCurrentSessionID = session;

            showPopup(changedExactly ? @"TikTok - Success" : @"TikTok - Result", message);

            // "Enterで終了": close only the panel. The floating menu button remains
            // because the original base adds it directly to the app window.
            menu.alpha = 0.0f;
        });
    });
}

static void initMenu(void) {
    menu = [[Menu alloc] initMenu];

    TextfieldItem *sessionItem = [[TextfieldItem alloc] init];
    sessionItem.Title = @"Session ID";
    sessionItem.Description = @"TikTok sessionid を入力。入力確定後、現在のUsernameを自動取得します。";
    sessionItem.IsOn = NO;
    sessionItem.DefaultValue = @"";

    TextfieldItem *usernameItem = [[TextfieldItem alloc] init];
    usernameItem.Title = @"New Username";
    usernameItem.Description = @"変更したい新しいUsernameを入力します。";
    usernameItem.IsOn = NO;
    usernameItem.DefaultValue = @"";

    InvokeItem *enterItem = [[InvokeItem alloc] init];
    enterItem.Title = @"Enter";
    enterItem.Description = @"Username変更APIを実行し、変更後のUsernameを自動確認してメニューを閉じます。";
    enterItem.FunctionPtr = &SNSExecuteUsernameChange;

    Page *page1 = [[Page alloc] initWithPageNumber:1 parentPage:1];
    [page1 addItem:sessionItem];
    [page1 addItem:usernameItem];
    [page1 addItem:enterItem];

    [menu addPage:page1];
    [menu setUserDefaultsAndDict];
    [menu loadPage:1];
    SNSAttachAndExposeMenu();

    // Show the Xelahot panel on the first launch so successful injection is
    // immediately obvious. The X button can reopen it after Enter closes it.
    menu.alpha = 1.0f;
}


static void SNSInitMenuOnce(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gMenuInitialized) {
            SNSAttachAndExposeMenu();
            return;
        }

        UIWindow *window = SNSActiveWindow();
        if (!window) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                SNSInitMenuOnce();
            });
            return;
        }

        gMenuInitialized = YES;
        initMenu();
        SNSAttachAndExposeMenu();
    });
}

static void applicationBecameReady(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        SNSInitMenuOnce();
    });
}


static NSString *SNSItemTitleForObservedTextField(UITextField *textField) {
    if (!menu || !textField) return nil;

    // Ignore every UITextField that does not belong to the Xelahot menu.
    UIView *ancestor = textField;
    while (ancestor && ancestor != menu) {
        ancestor = ancestor.superview;
    }
    if (ancestor != menu) return nil;

    NSInteger index = textField.tag;
    NSArray<UIView *> *items = menu.ScrollViewRef.subviews;
    if (index < 0 || index >= (NSInteger)items.count) return nil;

    UIView *itemView = items[(NSUInteger)index];
    for (UIView *subview in itemView.subviews) {
        if ([subview isKindOfClass:[UILabel class]]) {
            return ((UILabel *)subview).text;
        }
    }
    return nil;
}

static void SNSTextFieldDidEndEditing(NSNotification *notification) {
    id object = notification.object;
    if (![object isKindOfClass:[UITextField class]]) return;

    UITextField *textField = (UITextField *)object;
    NSString *title = SNSItemTitleForObservedTextField(textField);
    if ([title isEqualToString:@"Session ID"]) {
        SNS_OnSessionEntered(textField.text ?: @"");
    }
}

// Standalone dylib entry point.  This intentionally does not use Logos,
// MobileSubstrate, ElleKit, or CydiaSubstrate.  It is suitable for direct
// dylib injection into the app process.
__attribute__((constructor, used))
static void TikTokUsernameMenuConstructor(void) {
    @autoreleasepool {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSNotificationCenter *center = [NSNotificationCenter defaultCenter];

            [center addObserverForName:UIApplicationDidFinishLaunchingNotification
                                object:nil
                                 queue:[NSOperationQueue mainQueue]
                            usingBlock:^(__unused NSNotification *note) {
                applicationBecameReady();
            }];

            [center addObserverForName:UIApplicationDidBecomeActiveNotification
                                object:nil
                                 queue:[NSOperationQueue mainQueue]
                            usingBlock:^(__unused NSNotification *note) {
                applicationBecameReady();
            }];

            [center addObserverForName:UITextFieldTextDidEndEditingNotification
                                object:nil
                                 queue:[NSOperationQueue mainQueue]
                            usingBlock:^(NSNotification *note) {
                SNSTextFieldDidEndEditing(note);
            }];

            // Covers injection after didFinishLaunching/didBecomeActive already fired.
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                SNSInitMenuOnce();
            });
        });
    }
}
